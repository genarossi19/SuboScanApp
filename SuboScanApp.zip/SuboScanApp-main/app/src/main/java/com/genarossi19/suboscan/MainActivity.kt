package com.genarossi19.suboscan

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Toast
import com.genarossi19.suboscan.databinding.ActivityMainBinding
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var cameraId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnScanFrontal.setOnClickListener { initScannerFrontal() }
        binding.btnScan.setOnClickListener { initscanner() }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {


        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)

        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(this, "Cancelado", Toast.LENGTH_SHORT).show()
            } else {
                intent.putExtra("EXTRA_RESULT", result.contents)


                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("EXTRA_RESULT", result.contents)
                startActivity(intent)
                Log.i("Tivo0", (data.toString())) //-1
                Log.i(
                    "Tivo0",
                    (resultCode.toString())
                ) //Intent { act=com.google.zxing.client.android.SCAN flg=0x80000 (has extras) }
                Log.i("Tivo0", (requestCode.toString())) //49374
                Log.i("Tivo0", (result.toString())) //Toda la data
                Log.i("Tivo0", (result.contents.toString())) //http://www.pct.trenquelauquen.gov.ar

                val handler = Handler()
                handler.postDelayed({
                    // Código para la tarea que quieres ejecutar después de un tiempo determinado
                    initScannerFrontal()
                }, 5000)


            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun initResultActivity() {
        val intent = Intent(this, ResultActivity::class.java)

        startActivity(intent)
    }

    private fun initScannerFrontal() {
        val integrator = IntentIntegrator(this)

        integrator.setPrompt("ESCANEE QR EN EL RECUADRO")

        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val frontCameraId = getFrontCameraId(cameraManager)
        if (frontCameraId != null) {
            Log.i("Tivo0", "SE ENCONTRO UNA CAMARA FRONTAL PERO ME PINTO NO CARGARLA")
            integrator.setCameraId(frontCameraId)
            integrator.initiateScan()
        } else {
            Log.i("Tivo0", "NO SE ENCONTRO CAMARA FRONTAL")
            integrator.initiateScan()
        }
    }

    fun getFrontCameraId(cameraManager: CameraManager): Int? {
        val cameraIds = cameraManager.cameraIdList
        for (cameraId in cameraIds) {
            val characteristics = cameraManager.getCameraCharacteristics(cameraId)
            val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
            if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                return Integer.parseInt(cameraId)
            }
        }
        return null
    }

    private fun initscanner(){
        val integrator = IntentIntegrator(this)
        integrator.setPrompt("ESCANEE QR EN EL RECUADRO")
        integrator.initiateScan()
    }
}

