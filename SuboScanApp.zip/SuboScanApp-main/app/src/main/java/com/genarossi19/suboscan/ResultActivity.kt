package com.genarossi19.suboscan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.genarossi19.suboscan.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        binding = ActivityResultBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val extras = intent.extras
        if (extras != null && extras.containsKey("EXTRA_RESULT")) {
            val result = extras.getString("EXTRA_RESULT")
           val id_user = result ?: ""
        }else{

        }
    }
}